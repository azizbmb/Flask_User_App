from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import os

# Initialisation de l'application Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'votre_cle_secrete_ici'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///userdb.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialisation des extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Modèles de données
class UserLogin(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    
    # Relation avec UserInfo
    info = db.relationship('UserInfo', backref='userlogin', uselist=False)

class UserInfo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    fonction = db.Column(db.String(80), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user_login.id'), nullable=False)

# Configuration de Flask-Login
@login_manager.user_loader
def load_user(user_id):
    return UserLogin.query.get(int(user_id))

# Routes
@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = UserLogin.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        else:
            flash('Identifiant ou mot de passe incorrect')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    users = UserLogin.query.all()
    return render_template('dashboard.html', users=users)

@app.route('/add_user', methods=['GET', 'POST'])
@login_required
def add_user():
    if request.method == 'POST':
        username = request.form['username']
        password = generate_password_hash(request.form['password'])
        fonction = request.form['fonction']
        
        new_user = UserLogin(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        
        new_info = UserInfo(fonction=fonction, user_id=new_user.id)
        db.session.add(new_info)
        db.session.commit()
        
        flash('Utilisateur ajouté avec succès')
        return redirect(url_for('dashboard'))
    
    return render_template('user_form.html', action='Ajouter')

@app.route('/edit_user/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_user(id):
    user = UserLogin.query.get_or_404(id)
    
    if request.method == 'POST':
        user.username = request.form['username']
        if request.form['password']:
            user.password = generate_password_hash(request.form['password'])
        user.info.fonction = request.form['fonction']
        
        db.session.commit()
        flash('Utilisateur modifié avec succès')
        return redirect(url_for('dashboard'))
    
    return render_template('user_form.html', user=user, action='Modifier')

@app.route('/delete_user/<int:id>')
@login_required
def delete_user(id):
    user = UserLogin.query.get_or_404(id)
    info = UserInfo.query.filter_by(user_id=id).first()
    
    db.session.delete(info)
    db.session.delete(user)
    db.session.commit()
    
    flash('Utilisateur supprimé avec succès')
    return redirect(url_for('dashboard'))

# Création de la base de données
with app.app_context():
    db.create_all()
    
    # Ajout d'un utilisateur admin par défaut si la table est vide
    if not UserLogin.query.first():
        admin = UserLogin(username='admin', password=generate_password_hash('admin'))
        db.session.add(admin)
        db.session.commit()
        
        admin_info = UserInfo(fonction='Administrateur', user_id=admin.id)
        db.session.add(admin_info)
        db.session.commit()

if __name__ == '__main__':
    app.run(debug=True) 
